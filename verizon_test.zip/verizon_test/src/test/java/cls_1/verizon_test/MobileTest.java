package cls_1.verizon_test;

import org.testng.annotations.Test;

public class MobileTest {
	@Test
	void login()
	{
		System.out.println("test environment");
	}

}
